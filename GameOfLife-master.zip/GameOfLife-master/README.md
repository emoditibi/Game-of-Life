# GameOfLife
Cellular automaton, by the British mathematician John Horton Conway in 1970.

<a href="https://www.buymeacoffee.com/Soygaro" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>

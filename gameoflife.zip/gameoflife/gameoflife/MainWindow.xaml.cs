﻿using System;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace gameoflife
{
    public partial class MainWindow : Window
    {
        private bool Futas;
        private bool[,] AktGrid;
        private bool[,] nextGrid;
        private int sorok, oszlopok;
        private Thread szimulacio;
        private Rectangle[,] teglalapok;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Load;
            Closing += MainWindow_Closing;
        }

        private void MainWindow_Load(object sender, RoutedEventArgs e)
        {
         
        }

        private void InitializeGrid(int sorok, int oszlopok)
        {
            this.sorok = sorok;
            this.oszlopok = oszlopok;

            AktGrid = new bool[sorok, oszlopok];
            nextGrid = new bool[sorok, oszlopok];
            teglalapok = new Rectangle[sorok, oszlopok];

            for (int y = 0; y < sorok; y++)
            {
                for (int x = 0; x < oszlopok; x++)
                {
                    Rectangle rect = new Rectangle
                    {
                        Width = 9,
                        Height = 9,
                        Fill = Brushes.White
                    };
                    Canvas.SetLeft(rect, x * 10);
                    Canvas.SetTop(rect, y * 10);
                    canvasGrid.Children.Add(rect);
                    teglalapok[y, x] = rect;
                }
            }
        }

        private void GetNextState()
        {
            for (int y = 0; y < sorok; y++)
            {
                for (int x = 0; x < oszlopok; x++)
                {
                    int szomszedok = Countszomszedok(y, x);

                    if (AktGrid[y, x])
                    {
                        nextGrid[y, x] = szomszedok == 2 || szomszedok == 3;
                    }
                    else
                    {
                        nextGrid[y, x] = szomszedok == 3;
                    }
                }
            }

            var temp = AktGrid;
            AktGrid = nextGrid;
            nextGrid = temp;

            UpdateGrid();
        }

        private int Countszomszedok(int y, int x)
        {
            int szomszedok = 0;

            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (i == 0 && j == 0) continue;

                    int UjY = y + i;
                    int UjX = x + j;

                    if (UjY >= 0 && UjY < sorok && UjX >= 0 && UjX < oszlopok)
                    {
                        if (AktGrid[UjY, UjX])
                        {
                            szomszedok++;
                        }
                    }
                }
            }

            return szomszedok;
        }

        private void UpdateGrid()
        {
            for (int y = 0; y < sorok; y++)
            {
                for (int x = 0; x < oszlopok; x++)
                {
                    if (AktGrid[y, x])
                    {
                        teglalapok[y, x].Fill = Brushes.DarkOrange;
                    }
                    else
                    {
                        teglalapok[y, x].Fill = Brushes.White;
                    }

                }
            }
        }

        private void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            Start();
        }
        private void Start()
        {
            Futas = !Futas;
        
            if (Futas){ btnStart.Content = "Stop";}
            else{ btnStart.Content = "Start";}

            if (Futas)
            {
                szimulacio = new Thread(() =>
                {
                    while (Futas)
                    {
                        Dispatcher.Invoke(() =>
                        {
                            GetNextState();
                        });
                        Thread.Sleep(100); 
                    }
                });
                szimulacio.Start();
            }
            else
            {
                szimulacio?.Join();
            }
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Futas = false;
            szimulacio?.Join();
        }

        private void CanvasGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Point clickPosition = e.GetPosition(canvasGrid);
            int cellSize = 10;
            int xLoc = (int)(clickPosition.X / cellSize);
            int yLoc = (int)(clickPosition.Y / cellSize);

            if (xLoc >= 0 && xLoc < oszlopok && yLoc >= 0 && yLoc < sorok)
            {
                AktGrid[yLoc, xLoc] = !AktGrid[yLoc, xLoc];
                UpdateGrid();
            }
        }

        private void BtnChooseFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                LoadGridFromFile(filePath);
            }
        }

        private void LoadGridFromFile(string filePath)
        {
          
                string[] Sorok = File.ReadAllLines(filePath);
                int filesorok = Sorok.Length;
                int fileoszlopok = Sorok[0].Length;

                InitializeGrid(filesorok, fileoszlopok);

                for (int y = 0; y < filesorok; y++)
                {
                    string line = Sorok[y];
                    for (int x = 0; x < fileoszlopok; x++)
                    {
                        AktGrid[y, x] = line[x] == '1';
                    }
                }

                UpdateGrid();
            
           
        }
    }
    public class Cell
    {
        public Point Helye { get; private set; }
        public Size CellSize { get; private set; }
        public int XPos { get; private set; }
        public int YPos { get; private set; }
     

        public Cell(int x, int y, int cellSize)
        {
            XPos = x;
            YPos = y;
            CellSize = new Size(cellSize, cellSize);
            Helye = new Point(x * cellSize, y * cellSize);
        }
    }
}

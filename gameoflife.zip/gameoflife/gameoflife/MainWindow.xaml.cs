﻿using System;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace gameoflife
{
    public partial class MainWindow : Window
    {
        private bool InProgress;
        private bool[,] currentGrid;
        private bool[,] nextGrid;
        private int rows, cols;
        private Thread simulationThread;
        private Rectangle[,] cellRectangles;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Load;
            Closing += MainWindow_Closing;
        }

        private void MainWindow_Load(object sender, RoutedEventArgs e)
        {
         
        }

        private void InitializeGrid(int rows, int cols)
        {
            this.rows = rows;
            this.cols = cols;

            currentGrid = new bool[rows, cols];
            nextGrid = new bool[rows, cols];
            cellRectangles = new Rectangle[rows, cols];

            for (int y = 0; y < rows; y++)
            {
                for (int x = 0; x < cols; x++)
                {
                    Rectangle rect = new Rectangle
                    {
                        Width = 9,
                        Height = 9,
                        Fill = Brushes.White
                    };
                    Canvas.SetLeft(rect, x * 10);
                    Canvas.SetTop(rect, y * 10);
                    canvasGrid.Children.Add(rect);
                    cellRectangles[y, x] = rect;
                }
            }
        }

        private void GetNextState()
        {
            for (int y = 0; y < rows; y++)
            {
                for (int x = 0; x < cols; x++)
                {
                    int liveNeighbors = CountLiveNeighbors(y, x);

                    if (currentGrid[y, x])
                    {
                        nextGrid[y, x] = liveNeighbors == 2 || liveNeighbors == 3;
                    }
                    else
                    {
                        nextGrid[y, x] = liveNeighbors == 3;
                    }
                }
            }

            var temp = currentGrid;
            currentGrid = nextGrid;
            nextGrid = temp;

            UpdateGrid();
        }

        private int CountLiveNeighbors(int y, int x)
        {
            int liveNeighbors = 0;

            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (i == 0 && j == 0) continue;

                    int newY = y + i;
                    int newX = x + j;

                    if (newY >= 0 && newY < rows && newX >= 0 && newX < cols)
                    {
                        if (currentGrid[newY, newX])
                        {
                            liveNeighbors++;
                        }
                    }
                }
            }

            return liveNeighbors;
        }

        private void UpdateGrid()
        {
            for (int y = 0; y < rows; y++)
            {
                for (int x = 0; x < cols; x++)
                {
                    cellRectangles[y, x].Fill = currentGrid[y, x] ? Brushes.DarkOrange : Brushes.White;
                }
            }
        }

        private void BtnGo_Click(object sender, RoutedEventArgs e)
        {
            Go();
        }

        private void Go()
        {
            InProgress = !InProgress;
            btnGo.Content = InProgress ? "Stop" : "Go";

            if (InProgress)
            {
                simulationThread = new Thread(() =>
                {
                    while (InProgress)
                    {
                        Dispatcher.Invoke(() =>
                        {
                            GetNextState();
                        });
                        Thread.Sleep(100); // Example delay, adjust as needed
                    }
                });
                simulationThread.Start();
            }
            else
            {
                simulationThread?.Join();
            }
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            InProgress = false;
            simulationThread?.Join();
        }

        private void CanvasGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Point clickPosition = e.GetPosition(canvasGrid);
            int cellSize = 10;
            int xLoc = (int)(clickPosition.X / cellSize);
            int yLoc = (int)(clickPosition.Y / cellSize);

            if (xLoc >= 0 && xLoc < cols && yLoc >= 0 && yLoc < rows)
            {
                currentGrid[yLoc, xLoc] = !currentGrid[yLoc, xLoc];
                UpdateGrid();
            }
        }

        private void BtnChooseFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();


            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                LoadGridFromFile(filePath);
            }
        }

        private void LoadGridFromFile(string filePath)
        {
          
                string[] lines = File.ReadAllLines(filePath);
                int fileRows = lines.Length;
                int fileCols = lines[0].Length;

                InitializeGrid(fileRows, fileCols);

                for (int y = 0; y < fileRows; y++)
                {
                    string line = lines[y];
                    for (int x = 0; x < fileCols; x++)
                    {
                        currentGrid[y, x] = line[x] == '1';
                    }
                }

                UpdateGrid();
            
           
        }
    }
    public class Cell
    {
        public Point Location { get; private set; }
        public Size CellSize { get; private set; }
        public int XPos { get; private set; }
        public int YPos { get; private set; }
        public bool IsAlive { get; set; }
        public bool NextStatus { get; set; }

        public Cell(int x, int y, int cellSize)
        {
            XPos = x;
            YPos = y;
            CellSize = new Size(cellSize, cellSize);
            Location = new Point(x * cellSize, y * cellSize);
        }
    }
}

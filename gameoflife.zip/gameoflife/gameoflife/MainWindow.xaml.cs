﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace gameoflife
{
    public partial class MainWindow : Window
    {
        private bool InProgress;
        private bool[,] currentGrid;
        private bool[,] nextGrid;
        private int rows, cols;
        private Thread simulationThread;
        private Rectangle[,] cellRectangles;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Load;
            Closing += MainWindow_Closing;
        }

        private void MainWindow_Load(object sender, RoutedEventArgs e)
        {
            InitializeGrid();
            CreateGridSurface(true);
        }

        private void InitializeGrid()
        {
            rows = (int)(canvasGrid.ActualHeight / 10);
            cols = (int)(canvasGrid.ActualWidth / 10);

            currentGrid = new bool[rows, cols];
            nextGrid = new bool[rows, cols];
            cellRectangles = new Rectangle[rows, cols];

            for (int y = 0; y < rows; y++)
            {
                for (int x = 0; x < cols; x++)
                {
                    Rectangle rect = new Rectangle
                    {
                        Width = 9,
                        Height = 9,
                        Fill = Brushes.White
                    };
                    Canvas.SetLeft(rect, x * 10);
                    Canvas.SetTop(rect, y * 10);
                    canvasGrid.Children.Add(rect);
                    cellRectangles[y, x] = rect;
                }
            }
        }

        private void CreateGridSurface(bool randomCells)
        {
            Random random = new Random();

            for (int y = 0; y < rows; y++)
            {
                for (int x = 0; x < cols; x++)
                {
                    currentGrid[y, x] = randomCells && random.Next(100) < 15;
                }
            }

            UpdateGrid();
        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            CreateGridSurface(true);
        }

        private void GetNextState()
        {
            for (int y = 0; y < rows; y++)
            {
                for (int x = 0; x < cols; x++)
                {
                    int liveNeighbors = CountLiveNeighbors(y, x);

                    if (currentGrid[y, x])
                    {
                        nextGrid[y, x] = liveNeighbors == 2 || liveNeighbors == 3;
                    }
                    else
                    {
                        nextGrid[y, x] = liveNeighbors == 3;
                    }
                }
            }

            // Swap grids
            var temp = currentGrid;
            currentGrid = nextGrid;
            nextGrid = temp;

            UpdateGrid();
        }

        private int CountLiveNeighbors(int y, int x)
        {
            int liveNeighbors = 0;

            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (i == 0 && j == 0) continue;

                    int newY = y + i;
                    int newX = x + j;

                    if (newY >= 0 && newY < rows && newX >= 0 && newX < cols)
                    {
                        if (currentGrid[newY, newX])
                        {
                            liveNeighbors++;
                        }
                    }
                }
            }

            return liveNeighbors;
        }

        private void UpdateGrid()
        {
            for (int y = 0; y < rows; y++)
            {
                for (int x = 0; x < cols; x++)
                {
                    cellRectangles[y, x].Fill = currentGrid[y, x] ? Brushes.DarkOrange : Brushes.White;
                }
            }
        }

        private void BtnAdvance_Click(object sender, RoutedEventArgs e)
        {
            GetNextState();
        }

        private void BtnGo_Click(object sender, RoutedEventArgs e)
        {
            Go();
        }

        private void Go()
        {
            InProgress = !InProgress;
            btnGo.Content = InProgress ? "Stop" : "Go";

            if (InProgress)
            {
                simulationThread = new Thread(() =>
                {
                    while (InProgress)
                    {
                        Dispatcher.Invoke(() =>
                        {
                            GetNextState();
                            Thread.Sleep((int)sliderDelay.Value); // Ensuring this is executed on the UI thread
                        });
                    }
                });
                simulationThread.Start();
            }
            else
            {
                simulationThread?.Join();
            }
        }


        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            InProgress = false;
            simulationThread?.Join();
        }

        private void CanvasGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Point clickPosition = e.GetPosition(canvasGrid);
            int cellSize = 10;  // Assuming cell size of 10 for example
            int xLoc = (int)(clickPosition.X / cellSize);
            int yLoc = (int)(clickPosition.Y / cellSize);

            if (xLoc >= 0 && xLoc < cols && yLoc >= 0 && yLoc < rows)
            {
                currentGrid[yLoc, xLoc] = !currentGrid[yLoc, xLoc];
                UpdateGrid();
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            CreateGridSurface(false);
        }
    }

    public class Cell
    {
        public Point Location { get; private set; }
        public Size CellSize { get; private set; }
        public int XPos { get; private set; }
        public int YPos { get; private set; }
        public bool IsAlive { get; set; }
        public bool NextStatus { get; set; }

        public Cell(int x, int y, int cellSize)
        {
            XPos = x;
            YPos = y;
            CellSize = new Size(cellSize, cellSize);
            Location = new Point(x * cellSize, y * cellSize);
        }
    }
}
